package com.mymanager;

import android.app.Application;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.Configuration;

public class Config extends Application {

        @Override
        public void onCreate() {
            super.onCreate();

            Configuration dbConfiguration =
                    new Configuration.Builder(this).
                            setDatabaseName("mymanager.db").setModelClasses(AccountHistoryBean.class)
                            .create();

            ActiveAndroid.initialize(dbConfiguration);

        }
}
