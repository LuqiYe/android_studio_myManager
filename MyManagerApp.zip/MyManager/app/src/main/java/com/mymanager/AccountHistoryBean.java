package com.mymanager;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

@Table(name="AccountHistoryTable")
public class AccountHistoryBean extends Model {



    public AccountHistoryBean() {
    }



    @Column(name="trans_date" ,unique = true)
    private String date;
    @Column(name="transId" ,notNull = false)
    private String transId;

    @Column(name="cat" ,notNull = false)
    private String cat;
    @Column(name="amount" ,notNull = false)
    private String amount;


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "AccountHistoryBean{" +
                "date='" + date + '\'' +
                ", transId='" + transId + '\'' +
                ", cat='" + cat + '\'' +
                ", amount='" + amount + '\'' +
                '}';
    }
}
