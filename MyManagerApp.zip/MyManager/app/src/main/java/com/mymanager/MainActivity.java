package com.mymanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button butonUpdate=null,buttonHistory=null;


        butonUpdate=(Button)findViewById(R.id.buttonaccountUpdate);
        buttonHistory=(Button)findViewById(R.id.buttonAccountHistory);

        butonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),UpdateActivity.class));

            }
        });



        buttonHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),HistoryActivity.class));
            }
        });

    }
}
