package com.mymanager;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TextView;

import com.activeandroid.query.Select;

import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    TextView tv_total_bal;
    double total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        List<AccountHistoryBean> my_accounts=new Select().all().from(AccountHistoryBean.class).execute();
         tv_total_bal =(TextView)findViewById(R.id.tvBal);

        TableLayout my_history_table = (TableLayout)findViewById(R.id.tableHistory);
        my_history_table.removeAllViews();

        LayoutInflater inflater = (LayoutInflater)getSystemService( Context.LAYOUT_INFLATER_SERVICE );

        View v = inflater.inflate(R.layout.table_row,null);

        v.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

        TextView text_view_date = (TextView) v.findViewById(R.id.col1);
        text_view_date.setText("Date");
        TextView text_view_amount = (TextView) v.findViewById(R.id.txt_arr);
        text_view_amount.setText("Amount");
        TextView text_view_cat = (TextView) v.findViewById(R.id.txt_dep);
        text_view_cat.setText("Category");

        my_history_table.addView(v);

        for (AccountHistoryBean my_account_bean:my_accounts){
            {
                total+=Double.parseDouble(my_account_bean.getAmount());
                v = inflater.inflate(R.layout.table_row,null);
                text_view_date = (TextView) v.findViewById(R.id.col1);
                text_view_amount = (TextView) v.findViewById(R.id.txt_arr);
                text_view_cat = (TextView) v.findViewById(R.id.txt_dep);
                text_view_date.setText(my_account_bean.getDate());
                text_view_amount.setText(my_account_bean.getAmount());
                text_view_cat.setText(my_account_bean.getCat());

                my_history_table.addView(v);
            }
        }

        text_view_date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        text_view_amount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        text_view_cat.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        text_view_date.setTextColor(Color.BLACK);
        text_view_amount.setTextColor(Color.BLACK);
        text_view_cat.setTextColor(Color.BLACK);



        tv_total_bal.setText("Current balance: $"+total);
    }


    public void printTable(List<AccountHistoryBean> my_accounts)
    {

    }
}
