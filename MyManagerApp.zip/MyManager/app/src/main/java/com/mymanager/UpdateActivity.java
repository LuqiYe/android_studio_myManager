package com.mymanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.activeandroid.query.Select;

public class UpdateActivity extends AppCompatActivity {

    Button btnAdd,btnSpend;


    EditText editTextDate,editTextAmount,editTextCat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        btnAdd=(Button)findViewById(R.id.buttonAdd);
        btnSpend=(Button)findViewById(R.id.buttonSpend);
        editTextDate=(EditText)findViewById(R.id.editTextDate);
        editTextAmount=(EditText)findViewById(R.id.editTextAmount);
        editTextCat=(EditText)findViewById(R.id.editTextCat);



        btnSpend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AccountHistoryBean ub=new AccountHistoryBean();
                ub.setCat(editTextCat.getText().toString());
                ub.setDate(editTextDate.getText().toString());
                ub.setAmount("-"+editTextAmount.getText().toString());
                ub.save();
                editTextAmount.setText("");
                editTextDate.setText("");
                editTextCat.setText("");
                Toast.makeText(getApplicationContext(),"Saved to account",Toast.LENGTH_SHORT).show();

            }
        });




        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AccountHistoryBean ub=new AccountHistoryBean();
                int id=new Select().all().from(AccountHistoryBean.class).execute().size();
                ub.setTransId(""+id);
                ub.setCat(editTextCat.getText().toString());
                ub.setDate(editTextDate.getText().toString());
                ub.setAmount(editTextAmount.getText().toString());
                ub.save();
                editTextAmount.setText("");
                editTextDate.setText("");
                Toast.makeText(getApplicationContext(),"Saved to account",Toast.LENGTH_SHORT).show();
                editTextCat.setText("");

            }
        });

    }
}
